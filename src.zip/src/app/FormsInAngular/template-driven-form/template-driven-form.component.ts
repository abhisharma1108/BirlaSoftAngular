import { Component } from '@angular/core';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styleUrls: ['./template-driven-form.component.css']
})
export class TemplateDrivenFormComponent {



  submitted = false;
  userLogin(user: any) {
    console.log(user);
    console.log(user.email+" "+user.password);//userLogin(LoginForm.value)
    // console.log(user.email.value+" "+user.password.value); // LoginForm.controls
    this.submitted = true
  }

  onSubmit(user: any) {
    console.log(user);
    console.log(user.email+" "+user.password);//userLogin(LoginForm.value)
   //console.log(user.email.value+" "+user.password.value); // LoginForm.controls
    this.submitted = true
  }
}
