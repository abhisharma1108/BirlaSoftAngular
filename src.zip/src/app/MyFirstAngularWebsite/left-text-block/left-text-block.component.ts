import { Component } from '@angular/core';

@Component({
  selector: 'app-left-text-block',
  templateUrl: './left-text-block.component.html',
  styleUrls: ['./left-text-block.component.css']
})
export class LeftTextBlockComponent {

}
