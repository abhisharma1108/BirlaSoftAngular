import { Component } from '@angular/core';

@Component({
  selector: 'app-right-text-block',
  templateUrl: './right-text-block.component.html',
  styleUrls: ['./right-text-block.component.css']
})
export class RightTextBlockComponent {

}
