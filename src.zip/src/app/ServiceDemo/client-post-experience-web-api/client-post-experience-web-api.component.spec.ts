import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientPostExperienceWebAPIComponent } from './client-post-experience-web-api.component';

describe('ClientPostExperienceWebAPIComponent', () => {
  let component: ClientPostExperienceWebAPIComponent;
  let fixture: ComponentFixture<ClientPostExperienceWebAPIComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ClientPostExperienceWebAPIComponent]
    });
    fixture = TestBed.createComponent(ClientPostExperienceWebAPIComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
