import { Component, OnInit } from '@angular/core';
import { HttpUtilityServiceService } from '../http-utility-service.service';


@Component({
  selector: 'app-client-post-experience-web-api',
  templateUrl: './client-post-experience-web-api.component.html',
  styleUrls: ['./client-post-experience-web-api.component.css']
})
export class ClientPostExperienceWebAPIComponent implements OnInit {

constructor(private service : HttpUtilityServiceService ){

}

Employees : any =[];
  ngOnInit(): void {

    this.service.getEmployees().subscribe(Employees=> this.Employees = Employees);

  }
}
