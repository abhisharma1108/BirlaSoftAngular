import { Component, OnInit } from '@angular/core';
import { UtilityServiceService } from '../utility-service.service';

@Component({
  selector: 'app-consume-utility-service',
  templateUrl: './consume-utility-service.component.html',
  styleUrls: ['./consume-utility-service.component.css']
})
export class ConsumeUtilityServiceComponent implements OnInit {

  ProdName : string ="";
  Product :any= {};
  Products :any= [];
constructor(private service : UtilityServiceService  ){


}

ngOnInit(): void {
this.ProdName = this.service.ProductName;
this.Product = this.service.Product;
this.Products = this.service.products;

}
btnClick(){
this.service.ShowMessage();

}
}
