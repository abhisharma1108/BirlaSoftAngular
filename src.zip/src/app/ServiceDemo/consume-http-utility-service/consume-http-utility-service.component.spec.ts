import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsumeHttpUtilityServiceComponent } from './consume-http-utility-service.component';

describe('ConsumeHttpUtilityServiceComponent', () => {
  let component: ConsumeHttpUtilityServiceComponent;
  let fixture: ComponentFixture<ConsumeHttpUtilityServiceComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ConsumeHttpUtilityServiceComponent]
    });
    fixture = TestBed.createComponent(ConsumeHttpUtilityServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
