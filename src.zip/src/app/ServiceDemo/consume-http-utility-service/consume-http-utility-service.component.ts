import { Component, OnInit } from '@angular/core';
import { HttpUtilityServiceService } from '../http-utility-service.service';

@Component({
  selector: 'app-consume-http-utility-service',
  templateUrl: './consume-http-utility-service.component.html',
  styleUrls: ['./consume-http-utility-service.component.css']
})
export class ConsumeHttpUtilityServiceComponent implements OnInit {

Users : any =[];

constructor(private httpserv : HttpUtilityServiceService){}

ngOnInit(): void {
  console.log(this.httpserv.getUsers().subscribe(Users=> this.Users = Users));
this.httpserv.getUsers().subscribe(Users=> this.Users = Users);

}

}
