import { TestBed } from '@angular/core/testing';

import { HttpUtilityServiceService } from './http-utility-service.service';

describe('HttpUtilityServiceService', () => {
  let service: HttpUtilityServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HttpUtilityServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
