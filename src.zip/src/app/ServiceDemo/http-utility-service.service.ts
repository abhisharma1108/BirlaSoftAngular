import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpUtilityServiceService  {

  constructor(private http:HttpClient) { }
  getUsers():Observable<any>{
    return this.http.get('https://jsonplaceholder.typicode.com/users');

  }
getEmployees():Observable<any>{
    return this.http.get('http://localhost:5087/api/Employees');

  }

  readonly baseURL = "http://localhost:5087/api/Employees";
  postEmployee(data: any):Observable<any> {
    return this.http.post(this.baseURL, data);
  }

}
