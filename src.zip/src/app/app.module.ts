import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HeaderComponent } from './MyFirstAngularWebsite/header/header.component';
import { TopNavComponent } from './MyFirstAngularWebsite/top-nav/top-nav.component';
import { LeftTextBlockComponent } from './MyFirstAngularWebsite/left-text-block/left-text-block.component';
import { RightTextBlockComponent } from './MyFirstAngularWebsite/right-text-block/right-text-block.component';
import { OneWayBindingComponent } from './BindingDemo/one-way-binding/one-way-binding.component';
import { TwoWayBindingComponent } from './BindingDemo/two-way-binding/two-way-binding.component';
import { EventBindingComponent } from './BindingDemo/event-binding/event-binding.component';
import { NgIfDemoComponent } from './DirectiveDemo/ng-if-demo/ng-if-demo.component';
import { NgSwitchDemoComponent } from './DirectiveDemo/ng-switch-demo/ng-switch-demo.component';
import { NgForDemoComponent } from './DirectiveDemo/ng-for-demo/ng-for-demo.component';
import { Bootstrap5demoComponent } from './BootstrapDemo/bootstrap5demo/bootstrap5demo.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxBootstrapDemoComponent } from './BootstrapDemo/ngx-bootstrap-demo/ngx-bootstrap-demo.component';
import { PageNotFoundComponent } from './LoginSignOut/page-not-found/page-not-found.component';
import { PipeDemoComponent } from './PipeDemo/pipe-demo/pipe-demo.component';
import { ReverseStrPipe } from './PipeDemo/reverse-str.pipe';
import { UsesOfCustomPipeComponent } from './PipeDemo/uses-of-custom-pipe/uses-of-custom-pipe.component';
import { TemplateDrivenFormComponent } from './FormsInAngular/template-driven-form/template-driven-form.component';
import { ReactiveFormDemoComponent } from './FormsInAngular/reactive-form-demo/reactive-form-demo.component';
import { ConsumeUtilityServiceComponent } from './ServiceDemo/consume-utility-service/consume-utility-service.component';
import { ConsumeHttpUtilityServiceComponent } from './ServiceDemo/consume-http-utility-service/consume-http-utility-service.component';
import { ClientPostExperienceWebAPIComponent } from './ServiceDemo/client-post-experience-web-api/client-post-experience-web-api.component';
import { UserLoginComponent } from './LoginAndSignUp/user-login/user-login.component';
import { ToastrModule } from 'ngx-toastr';
const routes: Routes = [
  { path: 'UserLogin', component: UserLoginComponent },
  { path: 'Home', component: HeaderComponent },

  { path: 'OneWayBinding', component: OneWayBindingComponent },
  { path: 'TwoWayBinding', component: TwoWayBindingComponent},
  { path: 'EventBinding', component: EventBindingComponent },
  { path: 'NgIfDemo', component: NgIfDemoComponent },
  { path: 'NgSwitchDemo', component: NgSwitchDemoComponent },
  { path: 'NgForDemo', component: NgForDemoComponent },
  { path: 'PipeDemo', component: PipeDemoComponent },
  { path: 'UsesOfCustomPipe', component: UsesOfCustomPipeComponent },
  { path: 'TemplateDrivenForm', component: TemplateDrivenFormComponent },

  { path: 'ReactiveFormDemo', component: ReactiveFormDemoComponent },

  { path: 'ConsumeUtilityService', component: ConsumeUtilityServiceComponent },

  { path: 'ConsumeHttpUtilityService', component: ConsumeHttpUtilityServiceComponent },
  { path: 'ClientPostExperienceWebAPI', component: ClientPostExperienceWebAPIComponent },

  {path:'',
  redirectTo:'UserLogin',
  pathMatch:'full'},

  //Note Page Not Found always to be added in at last
  { path: '**', component: PageNotFoundComponent }

];
  @NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TopNavComponent,
    LeftTextBlockComponent,
    RightTextBlockComponent,
    OneWayBindingComponent,
    TwoWayBindingComponent,
    EventBindingComponent,
    NgIfDemoComponent,
    NgSwitchDemoComponent,
    NgForDemoComponent,
    Bootstrap5demoComponent,
    NgxBootstrapDemoComponent,
    PageNotFoundComponent,
    PipeDemoComponent,
    ReverseStrPipe,
    UsesOfCustomPipeComponent,
    TemplateDrivenFormComponent,
    ReactiveFormDemoComponent,
    ConsumeUtilityServiceComponent,
    ConsumeHttpUtilityServiceComponent,
    ClientPostExperienceWebAPIComponent,
    UserLoginComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule,
    HttpClientModule,
    ToastrModule.forRoot({ timeOut: 2000 ,enableHtml: true })

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
