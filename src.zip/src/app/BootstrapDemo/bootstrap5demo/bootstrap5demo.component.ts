import { Component } from '@angular/core';

@Component({
  selector: 'app-bootstrap5demo',
  templateUrl: './bootstrap5demo.component.html',
  styleUrls: ['./bootstrap5demo.component.css']
})
export class Bootstrap5demoComponent {

}
