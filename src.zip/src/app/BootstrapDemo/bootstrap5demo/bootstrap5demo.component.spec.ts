import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Bootstrap5demoComponent } from './bootstrap5demo.component';

describe('Bootstrap5demoComponent', () => {
  let component: Bootstrap5demoComponent;
  let fixture: ComponentFixture<Bootstrap5demoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Bootstrap5demoComponent]
    });
    fixture = TestBed.createComponent(Bootstrap5demoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
