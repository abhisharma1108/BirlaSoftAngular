import { Component } from '@angular/core';

@Component({
  selector: 'app-ngx-bootstrap-demo',
  templateUrl: './ngx-bootstrap-demo.component.html',
  styleUrls: ['./ngx-bootstrap-demo.component.css']
})
export class NgxBootstrapDemoComponent {

}
