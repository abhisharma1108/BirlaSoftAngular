import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgxBootstrapDemoComponent } from './ngx-bootstrap-demo.component';

describe('NgxBootstrapDemoComponent', () => {
  let component: NgxBootstrapDemoComponent;
  let fixture: ComponentFixture<NgxBootstrapDemoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NgxBootstrapDemoComponent]
    });
    fixture = TestBed.createComponent(NgxBootstrapDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
