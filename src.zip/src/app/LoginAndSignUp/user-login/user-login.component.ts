import { Component, OnInit } from '@angular/core';
import { NavbarService } from '../navbar.service';
import { HttpUtilityServiceService } from 'src/app/ServiceDemo/http-utility-service.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit{
  constructor(private nav:NavbarService,private employeeservice :HttpUtilityServiceService,private toastr:ToastrService){
  }

  signupObj: any = {
    firstName:'',
    lastName:'',
    password:'',
    landLine:'',
    cellNumber:'',
    email: '',

  };
  loginObj: any = {
    email: '',
    password: ''
  };

  onSignUp() {
    debugger
    // this.signupUsers.push(this.signupObj);
    // localStorage.setItem('signupUsers', JSON.stringify(this.signupUsers));
    // this.signupObj = {
    //   userName: '',
    //   email: '',
    //   password: ''
    // }
    this.employeeservice.postEmployee(this.signupObj).subscribe((result) => {
      this.toastr.success("register user successfully", "please Login  ");

    });
  }
  onLogin() {
    // this.userservice.getList().subscribe((result) => {
    //   console.warn(result)
    //   this.signupUsers = result
    }

  ngOnInit(): void {
    this.nav.hide();
    console.log()
    //const localData = localStorage.getItem('signupUsers');
    // if (localData != null) {
    //   this.signupUsers = JSON.parse(localData);

    // }



}

}
