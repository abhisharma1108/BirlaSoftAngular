import { Component } from '@angular/core';

@Component({
  selector: 'app-uses-of-custom-pipe',
  templateUrl: './uses-of-custom-pipe.component.html',
  styleUrls: ['./uses-of-custom-pipe.component.css']
})
export class UsesOfCustomPipeComponent {

  UserName: string = "ABHISHEK SHARMA";
  NameList :any = ['URFA', 'Manya', 'SRISHTI','KASAK'];


}
