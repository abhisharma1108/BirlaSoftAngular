import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-if-demo',
  templateUrl: './ng-if-demo.component.html',
  styleUrls: ['./ng-if-demo.component.css']
})
export class NgIfDemoComponent {
  isValid: boolean=false;
  buttonCaption = "Create Block";
  onCreateBlock()
  {
    if(this.isValid==true)
    {
    this.isValid=false;
    this.buttonCaption = "Create Block"
    }
    else{

      this.isValid=true;
      this.buttonCaption = "Remove Block"
    }
  }

}
